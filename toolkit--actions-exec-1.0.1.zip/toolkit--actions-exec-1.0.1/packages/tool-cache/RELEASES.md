# @actions/tool-cache Releases

### 1.1.0

- [Add zip and unzip for macOS](https://github.com/actions/toolkit/pull/49)
- [Support custom flags for `extractTar`](https://github.com/actions/toolkit/pull/48)

### 1.0.0

- Initial release