# @actions/github Releases

### 1.0.1

- Simplify WebPack configs by removing dynamic require - [#101](https://github.com/actions/toolkit/pull/101)

### 1.0.0

- Initial release
